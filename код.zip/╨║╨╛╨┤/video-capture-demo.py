# Підключення необхідних бібліотек
import cv2 # OpenCV
from os import path # Для шляху до файлу 

# Константи
VIDEO_PATH = path.join("data", "Lion.mp4") # Шлях до відео
CAMERA_INDEX = 0 # Індекс веб-камери

def main():
    while True:
        # Вибір джерела відео
        print("Оберіть джерело відео:")
        print("1. Відеофайл")
        print("2. Вебкамера")
        choise = input("Введіть номер (1 або 2): ")

        # Перевірка правильності вводу
        if choise in ["1", "2"]:
            choise = int(choise)
            break
        else:
            print("Некоректний ввід. Спробуйте ще раз.")

    # Метод зчитування даних з відеофайлу/вебкамери
    cap = cv2.VideoCapture(VIDEO_PATH if choise == 1 else CAMERA_INDEX) 

    # Перевірка готовності веб-камери
    while cap.isOpened():
        # Запис фреймів
        ret, frame = cap.read()
        # При виникненні помилці запису
        if not ret:
            print("Помилка запису фрейму!")
            break
        # Відображення результату
        cv2.imshow("frame", frame)
        # Натискання клавіші "q" для виходу з циклу
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Звільнення ресурсів, пов'язаних із відеофайлом
    cap.release()
    # Закриття всіх вікон OpenCV
    cv2.destroyAllWindows()

# При запуску як головного файлу
if __name__ == '__main__':
    main()
