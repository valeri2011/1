# Підключення необхідних бібліотек
import cv2 # OpenCV
from os import path # Для шляху до файлу
from numpy import zeros, ones, float32 # Для створення матриці
# Для вибору файлу з пк
from tkinter import filedialog

class VideoProcessor:
    # Константи режимів обробки відео
    MOTION_BLUR = 1
    CHANGE_COLORSPACE = 2
    CANNY_EDGE_DETECTION = 3
    TRANSFER = 4

    # Конструктор
    def __init__(self, video_source):
        self.__video_source = 0
        self.__mode = self.MOTION_BLUR
        self.set_video_source(video_source)
    
    def set_mode(self, mode):
        # Перевірка на валідність переданого режиму
        if mode not in [self.MOTION_BLUR, self.CHANGE_COLORSPACE, self.CANNY_EDGE_DETECTION, self.TRANSFER]:
            raise ValueError("Неправильний режим обробки відео")
        self.__mode = mode
    
    def set_video_source(self, video_source):
        if isinstance(video_source, int):
            self.__video_source = video_source
            return
        # Перевірка чи файл існує
        if not path.isfile(video_source):
            raise FileNotFoundError("Файл відео не існує")
        # Перевірка розширення файлу
        _, ext = path.splitext(video_source)
        if ext.lower() not in ['.avi', '.mp4', '.mov', '.mkv']:
            raise ValueError("Непідтримуваний формат відео")
        self.__video_source = video_source

    # Фільтрація з ефектом зсуву
    def __motion_blur(self, frame, kernel_size):
        # Створення матриці нулів розміром kernel_size x kernel_size для ядра рухового розмиття
        kernel_motion_blur = zeros((kernel_size, kernel_size))
        # Встановлення значень одиниць у центральному рядку матриці ядра рухового розмиття
        kernel_motion_blur[int((kernel_size - 1) / 2), :] = ones(kernel_size)
        # Нормалізація ядра рухового розмиття, ділення кожного значення на kernel_size
        kernel_motion_blur = kernel_motion_blur / kernel_size
        # Застосування фільтрації до зображення за допомогою ядра рухового розмиття
        return cv2.filter2D(frame, -1, kernel_motion_blur)

    # Зміна кольорового простору на HSV
    def __change_colorspace(self, frame):
        return cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    
    # Функція виділення виділення меж з різними порогами canny
    def __canny_edge_detection(self, image, t_lower=100, t_upper=200):
        # Перетворення кадру в колірний простір GRAY
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        # Виділення виділення меж з різними порогами canny
        edge = cv2.Canny(gray_image, t_lower, t_upper)
        return edge
    
    # Функція переносу зображення
    def __parallel_transfer(self, frame, left, top):
        # Отримання кількості рядків та стовпців у вихідному кадрі
        num_rows, num_cols = frame.shape[:2]
        # Створення матриці трансляції для здійснення зсуву кадру, де left - зсув по горизонталі, а top - зсув по вертикалі
        translation_matrix = float32([[1, 0, left], [0, 1, top]])
        # Перенос зображення
        transfered_frame = cv2.warpAffine(frame, translation_matrix, (num_cols, num_rows))
        return transfered_frame
    
    # Функція для обробки відеоданих
    def process(self, kernel_size=5, left=200, top=150, low = 100):
         # Метод зчитування даних з відеофайлу/вебкамери
        cap = cv2.VideoCapture(self.__video_source) 

        # Перевірка готовності веб-камери
        while cap.isOpened():
            # Запис фреймів
            ret, frame = cap.read()
            # При виникненні помилці запису
            if not ret:
                print("Помилка запису фрейму!")
                break

            # Обробка кадру в залежності від обраного режиму
            if self.__mode == self.CHANGE_COLORSPACE:
                frame = self.__change_colorspace(frame)
            if self.__mode == self.MOTION_BLUR:
                frame = self.__motion_blur(frame, kernel_size)
            if self.__mode == self.CANNY_EDGE_DETECTION:
                frame = self.__canny_edge_detection(frame, low, top)
            if self.__mode == self.TRANSFER:
                frame = self.__parallel_transfer(frame, left, top)

            # Відображення результату
            cv2.imshow("frame", frame)
            # Натискання клавіші "q" для виходу з циклу
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        # Звільнення ресурсів, пов'язаних із відеофайлом
        cap.release()
        # Закриття всіх вікон OpenCV
        cv2.destroyAllWindows()

def select_file():
    return filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov *.mkv")])

def main():
    choise = 0
    print("Програма для обробки відео")
    
    while True:
        # Вибір джерела відео
        print("Оберіть джерело відео:")
        print("1. Відеофайл")
        print("2. Вебкамера")
        choise = input("Введіть номер (1 або 2): ")

        # Перевірка правильності вводу
        if choise in ["1", "2"]:
            choise = int(choise)
            break
        else:
            print("Некоректний ввід. Спробуйте ще раз.")
    
    video_source = 0

    if choise == 1:
        video_source = select_file()
    
    video_processor = None

    try:
        video_processor = VideoProcessor(video_source)
    except ValueError as error:
        print(repr(error))
        return
    
    choise = 0

    while True:
        # Вибір режиму обробки відео
        print("Оберіть режим обробки:")
        print("1. Фільтр з ефектом зсуву")
        print("2. Зміна кольорового простору на HSV")
        print("3. Виділення меж порогами Canny")
        print("4. Перенесення")
        choise = input("Введіть номер (від 1 до 4): ")

        # Перевірка правильності вводу
        try:
            choise = int(choise)
        except:
            print("Некоректний ввід. Спробуйте ще раз.")
            continue
        if choise in [video_processor.CHANGE_COLORSPACE, video_processor.MOTION_BLUR, video_processor.CANNY_EDGE_DETECTION, video_processor.TRANSFER]:
            break
        else:
            print("Некоректний ввід. Спробуйте ще раз.")

    print(choise)

    if choise == video_processor.MOTION_BLUR:
        kernel_size = 0
        while True:
            kernel_size = int(input("Введіть розмір ядра (число): "))
            try:
                kernel_size = int(kernel_size)
            except:
                print("Некоректний ввід. Спробуйте ще раз.")
                continue
            break
        video_processor.set_mode(video_processor.MOTION_BLUR)
        video_processor.process(kernel_size=kernel_size)
    if choise == video_processor.CHANGE_COLORSPACE:
        video_processor.set_mode(video_processor.CHANGE_COLORSPACE)
        video_processor.process()
    if choise == video_processor.CANNY_EDGE_DETECTION:
        top = 0
        while True:
            top = int(input("Введіть верхню межу: "))
            try:
                top = int(top)
            except:
                print("Некоректний ввід. Спробуйте ще раз.")
                continue
            break
        low = 0
        while True:
            low = int(input("Введіть нижню межу: "))
            try:
                low = int(low)
            except:
                print("Некоректний ввід. Спробуйте ще раз.")
                continue
            break
        video_processor.set_mode(video_processor.CANNY_EDGE_DETECTION)
        video_processor.process(low=low, top=top)
    if choise == video_processor.TRANSFER:
        left = 0
        top = 0
        while True:
            top = int(input("Введіть зміщення по вертикалі: "))
            try:
                top = int(top)
            except:
                print("Некоректний ввід. Спробуйте ще раз.")
                continue
            break
        while True:
            left = int(input("Введіть зміщення по горизонталі: "))
            try:
                left = int(left)
            except:
                print("Некоректний ввід. Спробуйте ще раз.")
                continue
            break
        video_processor.set_mode(video_processor.TRANSFER)
        video_processor.process(left=left, top=top)
    


# При запуску як головного файлу
if __name__ == '__main__':
    main()
