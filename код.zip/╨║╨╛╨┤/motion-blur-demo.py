# Підключення необхідних бібліотек
import cv2 # OpenCV
from os import path # Для шляху до файлу
from numpy import zeros, ones # Для створення матриці

# Константи
VIDEO_PATH = path.join("data", "Lion.mp4") # Шлях до відео
CAMERA_INDEX = 0 # Індекс веб-камери

# Фільтрація з ефектом зсуву
def motion_blur(frame, kernel_size):
    # Створення матриці нулів розміром kernel_size x kernel_size для ядра рухового розмиття
    kernel_motion_blur = zeros((kernel_size, kernel_size))
    # Встановлення значень одиниць у центральному рядку матриці ядра рухового розмиття
    kernel_motion_blur[int((kernel_size - 1) / 2), :] = ones(kernel_size)
    # Нормалізація ядра рухового розмиття, ділення кожного значення на kernel_size
    kernel_motion_blur = kernel_motion_blur / kernel_size
    # Застосування фільтрації до зображення за допомогою ядра рухового розмиття
    return cv2.filter2D(frame, -1, kernel_motion_blur)

def main():
    while True:
        # Вибір джерела відео
        print("Оберіть джерело відео:")
        print("1. Відеофайл")
        print("2. Вебкамера")
        choise = input("Введіть номер (1 або 2): ")

        # Перевірка правильності вводу
        if choise in ["1", "2"]:
            choise = int(choise)
            break
        else:
            print("Некоректний ввід. Спробуйте ще раз.")

    # Метод зчитування даних з відеофайлу/вебкамери
    cap = cv2.VideoCapture(VIDEO_PATH if choise == 1 else CAMERA_INDEX) 

    # Перевірка готовності веб-камери
    while cap.isOpened():
        # Запис фреймів
        ret, frame = cap.read()
        # При виникненні помилці запису
        if not ret:
            print("Помилка запису фрейму!")
            break

        # Фільтрація з ефектом зсуву, kernel_size = 5
        frame = motion_blur(frame, 5)

        # Відображення результату
        cv2.imshow("frame", frame)
        # Натискання клавіші "q" для виходу з циклу
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Звільнення ресурсів, пов'язаних із відеофайлом
    cap.release()
    # Закриття всіх вікон OpenCV
    cv2.destroyAllWindows()

# При запуску як головного файлу
if __name__ == '__main__':
    main()
