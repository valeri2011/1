# Підключення необхідних бібліотек
import cv2 # OpenCV
from os import path # Для шляху до файлу
from numpy import float32 # Для роботи з матрицею 

# Константи
VIDEO_PATH = path.join("data", "Lion.mp4") # Шлях до відео
CAMERA_INDEX = 0 # Індекс веб-камери

# Функція переносу зображення
def parallel_transfer(frame, left, top):
    # Отримання кількості рядків та стовпців у вихідному кадрі
    num_rows, num_cols = frame.shape[:2]
    # Створення матриці трансляції для здійснення зсуву кадру, де left - зсув по горизонталі, а top - зсув по вертикалі
    translation_matrix = float32([[1, 0, left], [0, 1, top]])
    # Перенос зображення
    transfered_frame = cv2.warpAffine(frame, translation_matrix, (num_cols, num_rows))
    return transfered_frame

def main():
    while True:
        # Вибір джерела відео
        print("Оберіть джерело відео:")
        print("1. Відеофайл")
        print("2. Вебкамера")
        choise = input("Введіть номер (1 або 2): ")

        # Перевірка правильності вводу
        if choise in ["1", "2"]:
            choise = int(choise)
            break
        else:
            print("Некоректний ввід. Спробуйте ще раз.")

    # Метод зчитування даних з відеофайлу/вебкамери
    cap = cv2.VideoCapture(VIDEO_PATH if choise == 1 else CAMERA_INDEX) 

    # Перевірка готовності веб-камери
    while cap.isOpened():
        # Запис фреймів
        ret, frame = cap.read()
        # При виникненні помилці запису
        if not ret:
            print("Помилка запису фрейму!")
            break

        # Перенесення кадру на 180 по горизонталі та 320 по вертикалі
        frame = parallel_transfer(frame, 180, 320)

        # Відображення результату
        cv2.imshow("frame", frame)
        # Натискання клавіші "q" для виходу з циклу
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Звільнення ресурсів, пов'язаних із відеофайлом
    cap.release()
    # Закриття всіх вікон OpenCV
    cv2.destroyAllWindows()

# При запуску як головного файлу
if __name__ == '__main__':
    main()
